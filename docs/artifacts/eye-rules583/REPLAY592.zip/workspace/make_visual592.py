from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib
R=Path(__file__).resolve().parent;C=R/'Runtime590/R4/Turn20';D=R/'Deliverable592';D.mkdir(exist_ok=True)
assert json.loads((C/'status.json').read_text())['status']=='CAPTURED'
frames=[];source=[];boxes=[]
for f in range(20):
 canvas=Image.new('RGB',(1920,574),'#20252b');draw=ImageDraw.Draw(canvas)
 for x,side,label in [(0,'OFF','583 sampled lash region / iris582 ON'),(960,'ON','592 closed-boundary lash region / iris582 ON')]:
  path=C/f'{f:03}_{side}.png';src=Image.open(path).convert('RGB');assert src.size==(960,544);canvas.paste(src,(x,30));draw.text((x+12,8),label+' / actual frame '+str(f),fill='white');source.append({'frame':f,'side':side,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
  params=json.loads((C/f'{f:03}_{side}_PARAMS.json').read_text());assert params['irisSupport582'] and params['lashRegion583'] and params['closedLash590']==(side=='ON')
  import struct
  w,h,rx,ry=struct.unpack_from('<4i',(C/f'{f:03}_{side}_EYE_VISIBLE.bin').read_bytes());xx=rx+params['offsetX'];yy=ry-params['offsetY'];boxes.append((2*xx,2*yy,2*(xx+w),2*(yy+h)))
 frames.append(canvas)
dur=[round((i+1)*1000/60)-round(i*1000/60) for i in range(20)]
frames[0].save(D/'Turn20_592.webp',save_all=True,append_images=frames[1:],duration=dur,loop=0,lossless=True,quality=100,method=6)
thumb=Image.new('RGB',(480,136*20))
for i,im in enumerate(frames):thumb.paste(im.resize((480,136),Image.Resampling.NEAREST),(0,i*136))
palette=thumb.quantize(colors=256,method=Image.Quantize.MEDIANCUT);gif=[im.quantize(palette=palette,dither=Image.Dither.NONE) for im in frames];gd=[(round((i+1)*100/60)-round(i*100/60))*10 for i in range(20)]
gif[0].save(D/'Turn20_592.gif',save_all=True,append_images=gif[1:],duration=gd,loop=0,optimize=False,disposal=2)
frames[4].save(D/'Fullbody004_592.png')
box=(max(0,min(b[0] for b in boxes)-12),max(0,min(b[1] for b in boxes)-16),min(960,max(b[2] for b in boxes)+12),min(544,max(b[3] for b in boxes)+12))
scale=3;cw=(box[2]-box[0])*scale;ch=(box[3]-box[1])*scale+20;head=Image.new('RGB',(cw*5,ch*8),'#20252b');draw=ImageDraw.Draw(head)
for f in range(20):
 for side,rowOffset in [('OFF',0),('ON',1)]:
  col=f%5;row=(f//5)*2+rowOffset;im=Image.open(C/f'{f:03}_{side}.png').convert('RGB').crop(box).resize((cw,ch-20),Image.Resampling.NEAREST);head.paste(im,(col*cw,row*ch+20));draw.text((col*cw+4,row*ch+3),str(f)+' '+('583' if side=='OFF' else '592'),fill='white')
head.save(D/'All20Heads592.png')
info={'sourceRun':str(C),'sourceFrames':source,'scope':'Actual Walk + RotateTowards 20-frame excerpt, not full loop. Both iris582/lash583 ON; only closedLash590 differs. Same hair579/clothing547. No source crop/rescale/interpolation in full-body movies. Headers only. Repetition seam is not validated.','headContact':{'crop':box,'scale':scale,'inspectionOnly':True}}
for name in ['Turn20_592.webp','Turn20_592.gif']:
 im=Image.open(D/name);assert im.n_frames==20;timing=[]
 for f in range(20):
  im.seek(f);im.load();timing.append(im.info.get('duration',0))
  if name.endswith('webp'):assert im.convert('RGB').tobytes()==frames[f].tobytes(),f
 info[name]={'bytes':(D/name).stat().st_size,'frames':20,'durationMs':sum(timing),'frameDurations':timing,'size':[1920,574],'lossless':name.endswith('webp'),'sha256':hashlib.sha256((D/name).read_bytes()).hexdigest()}
(D/'VISUAL592.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps({k:v for k,v in info.items() if k.startswith('Turn')},indent=2))
