# 590 닫힌 속눈썹 영역 전환 — 구현 전 계약

이번 변경은 승인된 속눈썹 경로만 바꾼다. `UseLashRegion583`은 계속 기본 OFF다. 홍채582·흰자·아래눈꺼풀·기존 비실험 경로는 보존한다. 검증 전 미술 채택이나 시간 품질 합격으로 표시하지 않는다.

입력은 기존 ModelEye.closedBoundary의 정점 ID, 원본 head-bind rest 좌표, 현재 변형된 Face 정점이다. rest의 눈 축·반경으로 정규화한 u/v에서 좌우 극점을 연결하는 두 경계 chain 중 길이 가중 평균 v가 작은 chain을 윗경계로 고른다. 모델/포즈/화면좌표별 예외가 없다. 각 native 경계 segment에 기존 Classify의 바깥 .36·안쪽 .22 두께를 현재 head-up 벡터로 적용하여 닫힌 ribbon quad를 만든다. 폭은 기존 디자인 상수이며 새로운 최소픽셀 규칙이 아니다. 개구부 곡선은 native 경계로 전환하므로 기존 polynomial 중심선과 픽셀 수가 같다는 주장은 하지 않는다.

`closedBoundary/rest → 현재 변형 정점(world) → head-up 두께를 가진 닫힌 ribbon → 기존 effectiveProjection/view → 좌상단480×272 논리 좌표 → 기존 CurveArea511 positive-winding union → 논리 셀 내부16개 subcell의 연속 면적 → GPU 후보/가림 → N=floor(A+.5)와 기존 rank → 별도 원본 색 공급 → 기존 합성` 순서다. source RGBA/META의 알파 통과는 ribbon 존재·면적·후보의 조건이 아니다.

면적은 geometry만의 기존 CurveArea511 연속 polygon 계산을 재사용한다. visibility는 기존 HairMETA/S4·S5눈썹·S6몸의4×4 표본과 같은 sample ray의 ribbon 기하 깊이를 비교한다. subcell 안의 모든 연속 가림을 증명하는 방법이 아니며, 정확한 GPU 알파/half 재현이나587~589 면적 실험을 되살리지 않는다. 원본 링의 rest winding과 모델 normal 관계로 현재 링의 앞면을 정하며 뒷면은 채우지 않는다. 가림을 제거하거나 이전 프레임을 복사하지 않는다.

GPU packet은 ROI의4×4 subcell마다 geometry area/depth/rest-u/rest-v 네 float다. 두 눈만 전송하며 full-frame 고해상도RT나 CPU readback이 없다. 항상 바인딩할 최소 dummy buffer를 두고 옵션ON일 때만 생성한다. ROI는 ribbon의 실제 bounds를 포함한다. 기하 support는 기존 원본 primitive가 아닌 별도 sentinel4로 표시하며 native UV/barycentric을 위조하지 않는다.

색 공급은 현재 같은 눈 S3의 기존 nearest source pigment를 재사용한다. 해당 눈 S3가 완전히 비면 기존 template의 같은 눈 role6 pigment를 사용한다. 템플릿 색은 같은 인스턴스의 기준 원본 색이며 이전 프레임 덮개가 아니다. 색 공급 실패는 별도 진단 상태로 남으며 면적/후보를 원본 알파로 자르지 않는다. current-lighting과template pigment의 차이는 실제 렌더 검증 대상이다.

첫 검사: 순수C# helper에서 닫힘·chain 방향/순서 불변·fractional 영역·overlap union·정상축소·완전가림 모델·depth/u/v plane·subcell y반전 검사를 한다. 저장된9포즈는 원본 vertex/triangle/rest를 재사용할 수 있는 범위에서만 검증하며 없는 현재 변형 offset/가림을 복원했다고 주장하지 않는다. 이후 전체 C# Roslyn과D3D11 HLSL 정적 컴파일을 수행한다. 실제 Unity import/compile·9포즈·3출몰·정상 가림·실제 보행/회전·3방향·전신영상·GPU비용은 라이선스 활성화 뒤 별도 필수 gate다. 실패한 최소 검사는 수정하며 실제 검증 없이 기본ON/미술채택하지 않는다.
