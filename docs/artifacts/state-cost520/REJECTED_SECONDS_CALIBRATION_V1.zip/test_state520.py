"""Minimum properties and counterexamples BEFORE Walk sensitivity."""
from pathlib import Path
import json,math,time,itertools,hashlib
import numpy as np
import active516 as G,state520 as S
W=G.ROOT;D=W/'State520';real=json.loads((D/'PREFLIGHT520.json').read_text());assert real['preconditionPassed'];good,bad=real['rows'];delta=bad['spatial']['total']-good['spatial']['total'];raw=real['recoverRaw519'];assert raw==real['reverseRaw519'];matrix=[[0,raw],[raw,0]];rows=[];recoveries=[]

for eta in[.5,1.,2.]:
    kernel=S.StateCost(matrix,eta,[0.,math.inf]);bound=kernel.beta*raw/delta;history=[];dt=1/60
    for k in range(math.ceil((bound+1)*60)):
        chosen=kernel.step([delta,0.],dt);history.append({'seconds':kernel.seconds,'drawing':'current'if chosen else'past','values':kernel.value.tolist()})
    first=next(r['seconds']for r in history if r['drawing']=='current');assert first<=bound+dt+1e-10;assert history[-1]['drawing']=='current'
    recoveries.append({'etaSeconds':eta,'oldFramewiseRecoverMinusStay':kernel.beta*raw-delta,'finiteBarrier':kernel.beta*raw,'currentEvidenceRateAdvantage':delta,'theoreticalRecoverySeconds':bound,'observedRecoverySeconds60Hz':first,'oneTransitionCellChanges':real['differentCells'],'oldArea':bad['spatial']['area'],'recoveredArea':good['spatial']['area'],'oldStairRatioReversals':bad['stairRhythm']['stairRatioReversalsDiagnostic'],'recoveredStairRatioReversals':good['stairRhythm']['stairRatioReversalsDiagnostic'],'history':history})
rows.append({'name':'real-stationary12cell-recovery-for-all3weights','passed':True,'recoveries':recoveries})

# Equal physical evidence with different partitions must give equal potentials.
for eta in[.5,1.,2.]:
    outputs=[]
    for hz in[30,60,120]:
        kernel=S.StateCost(matrix,eta,[0.,math.inf])
        for i in range(6*hz):kernel.step([delta,0.],1/hz)
        outputs.append(kernel.value.copy())
    assert max(float(np.max(abs(v-outputs[0])))for v in outputs)<1e-10
rows.append({'name':'physical-time-partition-invariance-on-stationary-input','passed':True,'ratesHz':[30,60,120],'seconds':6,'scope':'Piecewise-constant evidence and fixed valid geometry, not invented missing Walk poses.'})

# Three-state composition uses explicit raw edit paths; it is not a lowered
# coordinate threshold. A nonmetric direct edit must not break the semigroup.
raw3=[[0,2,10],[2,0,2],[10,2,0]];k=S.StateCost(raw3,1,[0,math.inf,math.inf]);assert abs(k.cost[0,2]-k.beta*4)<1e-12 and k.paths[0][2]==[0,1,2]
one=S.StateCost(raw3,1,[0,math.inf,math.inf]);many=S.StateCost(raw3,1,[0,math.inf,math.inf]);one.step([.4,.2,0],2)
for i in range(120):many.step([.4,.2,0],1/60)
assert np.max(abs(one.value-many.value))<1e-10
rows.append({'name':'multi-state-edit-path-closure-and-semigroup','passed':True,'directRaw':10,'explicitComposedRaw':4,'path':[0,1,2],'rawEdgeCostsChanged':False,'effectiveReachableBarrierCanDifferFromOneDirectEdit':True})

zero=S.StateCost(matrix,1,[0,math.inf]);before=zero.value.copy()
for i in range(100):zero.step([delta,0],0)
assert np.array_equal(before,zero.value)
balanced=S.StateCost(matrix,1,[0,math.inf])
for i in range(120):balanced.step([0,0],1/60)
assert balanced.value[0]==0 and balanced.value[1]>0
rows.append({'name':'no-unconditional-timer-or-zero-dt-accumulation','passed':True,'equalEvidenceDoesNotErasePrior':True})

# Transport validity is provided by the frozen correspondence. State labels
# follow current geometry; retaining a design state cannot freeze screen space.
moving=S.StateCost(matrix,1,[0,math.inf]);positions=[]
for i in range(120):
    chosen=moving.step([0,delta],1/60);assert chosen==0;positions.append(i/30.)
assert positions[-1]-positions[0]>3.9
rows.append({'name':'sustained-rigid-motion-is-permitted','passed':True,'stateLabel':0,'geometryPositionTravel':positions[-1]-positions[0],'scope':'Kernel property under an explicitly valid co-moving correspondence; no new actual Walk result.'})

# Partial event restart must preserve the unaffected component's prior.
old=list(itertools.product(range(2),range(2)));values=[0.,1.,2.,3.];restart=[]
for event,count in[('explicit-occlusion-reappearance',2),('split',3),('merge',1)]:
    current=list(itertools.product(range(2),range(count)));prior=S.restart_marginal(old,values,current,[0],current);assert np.all(prior==np.array([0. if u==0 else 2. for u,a in current]))
    rawCurrent=[[4*(u!=v)+(a!=b)for v,b in current]for u,a in current];kernel=S.StateCost(rawCurrent,1,prior,keys=current);energy=[.5*(u==0)+(a!=count-1)for u,a in current];selected=kernel.step(energy,.01);assert current[selected][0]==0
    restart.append({'event':event,'oldStates':len(old),'newStates':len(current),'selected':current[selected],'affectedPrior':'UNAVAILABLE','eventTransitionCost':None,'unaffectedPriorPreserved':True})
rows.append({'name':'component-marginal-restart-preserves-unaffected-history','passed':True,'events':restart})

# The tempting alternatives fail: clear all history, or retain only coupled
# whole-drawing hypotheses. Keep those failures visible, never report reset0.
current=list(itertools.product(range(2),range(2)));cost=[[4*(u!=v)+(a!=b)for v,b in current]for u,a in current];wrong=S.StateCost(cost,1,None,keys=current);idx=wrong.step([.5*(u==0)+(a!=1)for u,a in current],.01);assert current[idx][0]==1
restricted=[(0,0),(1,1)];rejection=None
try:S.restart_marginal(restricted,[0,2],restricted,[0],current)
except ValueError as exc:rejection=str(exc)
assert rejection is not None
rows.append({'name':'whole-reset-and-truncated-whole-drawing-bank-counterexamples','passedAsExpectedRejection':True,'wholeResetWronglyChangesUnaffectedTo':current[idx],'truncatedBankRejected':rejection})

# Strict persistent advantage removes initial-state dependence. Balanced
# periodic alternatives do not define a unique design; do not promise one.
strict=[]
for init in[[0,math.inf],[math.inf,0]]:
    k=S.StateCost(matrix,1,init)
    for i in range(6*60):selected=k.step([delta,0],1/60)
    strict.append(selected)
assert strict==[1,1]
cycles=[]
for init in[[0,math.inf],[math.inf,0]]:
    k=S.StateCost(matrix,1,init);ends=[]
    for loop in range(10):
        for frame in range(60):selected=k.step([0,.4]if frame<30 else[.4,0],1/60)
        ends.append(selected)
    cycles.append(ends)
rows.append({'name':'loop-initial-state-properties','strictAdvantagePassed':True,'strictOutputs':strict,'balancedPeriodicEndStates':cycles,'balancedInitialStateIndependenceGuaranteed':False,'scope':'Equal cycle energy can retain distinct stable choices. This is not proof that actual Walk startup quality is acceptable.'})
out={'finiteStateContractPropertiesPassed':True,'existingSelectorApplicationGatePassed':False,'reason':'The516 selector retains one emitted previous span set, not alternative value states; a restricted whole-drawing bank cannot implement component-only marginal restart without missing feasible combinations. The kernel alone does not repair that search/state representation.','tests':rows,'newStateCostKernelImplementedOffline':True,'newWalkSensitivityRun':False,'etaValues':[.5,1.,2.],'etaUnitInReplacement':'seconds relative to current shape energy rate, not calibrated old per-frame strengths','newUnityCalls':0,'productChanged':False,'newFillPhysicalVisibility':'UNVERIFIED','validatedCorrespondenceChanged':False}
(D/'MINIMUM520.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'finiteStateContractPropertiesPassed':True,'existingSelectorApplicationGatePassed':False,'recoverySeconds':[{'eta':r['etaSeconds'],'bound':r['theoreticalRecoverySeconds'],'observed':r['observedRecoverySeconds60Hz']}for r in recoveries],'wholeResetNegativeExample':current[idx],'truncatedBankRejection':rejection,'balancedLoopInitialStates':cycles,'walkSensitivityRun':False},ensure_ascii=False),flush=True)
