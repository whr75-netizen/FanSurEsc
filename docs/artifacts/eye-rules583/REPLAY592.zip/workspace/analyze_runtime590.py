from pathlib import Path
import struct,json,csv,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent;tag=sys.argv[1] if len(sys.argv)>1 else 'R2';C=R/'Runtime590'/tag;D=R/('Deliverable'+tag);D.mkdir(exist_ok=True)
def buf(path):
 raw=path.read_bytes();w,h,x,y=struct.unpack_from('<4i',raw);return x,y,np.frombuffer(raw,'<f4',offset=16).reshape(h,w,4)
def series(z,eye,ids):return int(np.count_nonzero((z[:,:,1]==eye)&np.isin(z[:,:,0],ids)))
results=[];costs=[];contact_rows=[]
for run in (sys.argv[2].split(',') if len(sys.argv)>2 else ['Frozen2','Frozen5','Frozen16','Reg80','Reg170','Reg260','Turn20']):
 root=C/run;status=json.loads((root/'status.json').read_text());assert status['status']=='CAPTURED',status
 frames=sorted(int(p.name[:3]) for p in root.glob('*_ON.png'));assert len(frames)==status['poses']
 rows=[];counts={side:{str(eye):{feature:[] for feature in ['lash','iris','sclera','lowerLid']} for eye in [1,2]} for side in ['OFF','ON']}
 for f in frames:
  pre={side:root/f'{f:03}_{side}' for side in ['OFF','ON']};params={s:json.loads(Path(str(p)+'_PARAMS.json').read_text()) for s,p in pre.items()}
  assert params['OFF']['phase']==params['ON']['phase']
  assert Path(str(pre['OFF'])+'_CAMERA.bin').read_bytes()==Path(str(pre['ON'])+'_CAMERA.bin').read_bytes()
  assert Path(str(pre['OFF'])+'_TIME.txt').read_bytes()==Path(str(pre['ON'])+'_TIME.txt').read_bytes()
  for p in pre.values():assert 'bitChannelDiff=0' in Path(str(p)+'_EYE_INPUT.txt').read_text()
  b={s:buf(Path(str(p)+'_EYE_VISIBLE.bin')) for s,p in pre.items()};a=b['OFF'];n=b['ON'];assert a[:2]==n[:2] and a[2].shape==n[2].shape
  intrinsic={s:buf(Path(str(p)+'_EYE_INTRINSIC.bin')) for s,p in pre.items()}
  png={s:np.array(Image.open(str(p)+'.png').convert('RGB')) for s,p in pre.items()};diff=np.any(png['OFF']!=png['ON'],axis=2);outside=diff.copy();x=a[0]+params['ON']['offsetX'];y=a[1]-params['ON']['offsetY'];h,w=a[2].shape[:2]
  outside[max(0,y*2):min(diff.shape[0],(y+h)*2),max(0,x*2):min(diff.shape[1],(x+w)*2)]=False
  ma=buf(Path(str(pre['OFF'])+'_META.bin'))[2];mn=buf(Path(str(pre['ON'])+'_META.bin'))[2];sil=((ma[:,:,0]>0)&(ma[:,:,1]>.5))!=((mn[:,:,0]>0)&(mn[:,:,1]>.5))
  for side in ['OFF','ON']:
   for eye in [1,2]:
    for feature,ids in [('lash',[5,7]),('iris',[2,3,4]),('sclera',[1]),('lowerLid',[6])]:counts[side][str(eye)][feature].append(series(b[side][2],eye,ids))
  v=json.loads(Path(str(pre['ON'])+'_VIEW579.json').read_text())
  rows.append({'frame':f,'yaw':v['yaw'],'phase':params['ON']['phase'],'changedRGBPixels':int(diff.sum()),'outsideEyeChangedRGBPixels':int(outside.sum()),'savedROISilhouetteChanges':int(sil.sum()),'intrinsicChangedCells':int(np.any(intrinsic['OFF'][2]!=intrinsic['ON'][2],axis=2).sum()),'irisToOtherThanLashCells':int(np.count_nonzero(np.isin(a[2][:,:,0],[2,3,4])&~np.isin(n[2][:,:,0],[2,3,4,5,7]))),'scleraToOtherThanLashCells':int(np.count_nonzero((a[2][:,:,0]==1)&~np.isin(n[2][:,:,0],[1,5,7])))})
  if f==0 or run.startswith('Frozen'):
   crop=(max(0,int(x*2-12)),max(0,int(y*2-12)),min(960,int((x+w)*2+12)),min(544,int((y+h)*2+12)))
   strip=Image.new('RGB',(800,160),'#20252b');draw=ImageDraw.Draw(strip)
   for xx,side in [(0,'OFF'),(400,'ON')]:
    im=Image.open(str(pre[side])+'.png').convert('RGB').crop(crop);scale=min(390/im.width,130/im.height);im=im.resize((int(im.width*scale),int(im.height*scale)),Image.Resampling.NEAREST);strip.paste(im,(xx,25));draw.text((xx+4,5),f'{run}/{f} '+('583' if side=='OFF' else '590'),fill='white')
   contact_rows.append(strip)
 transitions=[]
 for side in counts:
  for eye in counts[side]:
   for feature,values in counts[side][eye].items():
    for i in range(1,len(values)-1):
     if (values[i-1]>0)==(values[i+1]>0) and (values[i]>0)!=(values[i-1]>0):transitions.append({'side':side,'eye':eye,'feature':feature,'frame':i,'counts':values[i-1:i+2]})
 for line in (root/'COST590.tsv').read_text().splitlines():
  f,side,ms,alloc,bytes_=line.split('\t');costs.append({'run':run,'frame':int(f),'side':side,'renderCallMilliseconds':float(ms),'renderCallManagedBytes':int(alloc),'geometryBufferBytes':int(bytes_)})
 result={'run':run,'status':status,'pairs':rows,'counts':counts,'presenceReversals':transitions};results.append(result);print(json.dumps({'run':run,'pairs':len(rows),'outsideEyeChanges':sum(r['outsideEyeChangedRGBPixels'] for r in rows),'silhouetteChanges':sum(r['savedROISilhouetteChanges'] for r in rows),'counts':counts,'presenceReversals':transitions},ensure_ascii=True))
out={'pairs':sum(len(r['pairs']) for r in results),'runs':results,'scope':'Same-frame583/590 comparison; iris582 ON and existing hair/clothing equal. OFF/ON filenames refer only to UseClosedLash590. Intrinsic shape changes are expected and reported.','costs':costs}
(R/('ACTUAL_VALIDATION_'+tag+'.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
contact=Image.new('RGB',(800,160*len(contact_rows)),'#20252b')
for i,im in enumerate(contact_rows):contact.paste(im,(0,i*160))
contact.save(D/'ActualContacts590.png')
