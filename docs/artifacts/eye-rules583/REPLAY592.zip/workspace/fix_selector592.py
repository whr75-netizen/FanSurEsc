from pathlib import Path
import subprocess,difflib,hashlib,json
R=Path(__file__).resolve().parent;P=Path(r'C:\Users\15352\Documents\work\Fantasy Survival Escape Game');rel='Assets/EUnityValidation01/EyeBoundaryRestore348/Shaders/EyeFeature348.compute';path=P/rel
old=path.read_text('utf-8-sig');baseline=subprocess.check_output(['git','-C',str(P),'show','0b8f897:'+rel]).decode('utf-8');head=subprocess.check_output(['git','-C',str(P),'show','HEAD:'+rel]).decode('utf-8');assert old==head,'Shader changed independently'
(R/'BEFORE_SELECTOR_R2_590.compute').write_text(old,encoding='utf-8')
a=baseline.index('FeatureSample583 Sample583(');b=baseline.index('\nint Choose(',a);original_sample=baseline[a:b]
a=old.index('FeatureSample583 Sample583(');b=old.index('\nint Choose(',a)
curve='''
// Independent geometric overlay. A partial ribbon never reclassifies a whole
// iris/sclera sample; those original samples remain available to the selector.
FeatureSample583 CurveSample590(int2 p,int eye,int k){FeatureSample583 r=(FeatureSample583)0;r.support=-1;float4 g=LashGeometry590(p,eye,k);if(g.x<=0||g.y<=0)return r;
 r.feat=5;r.support=4;r.depth=g.y;r.rest=_Centres348[eye].xyz+_AxesX348[eye].xyz*(g.z*_AxesX348[eye].w)-_AxesY348[eye].xyz*(g.w*_AxesY348[eye].w);float weight=g.x;int2 q=(p-_ROI348.xy)*4+int2(k%4,k/4);
 float4 hair=_UseHairRegion502!=0?_HairMETA.Load(int3(p,0)):_S4META.Load(int3(q,0)),br=_S5META.Load(int3(q,0)),body=_S6META.Load(int3(q,0));
 if(cov(hair)&&hair.x<g.y){weight*=1-saturate(hair.w);r.hairBlocked=1;}if(cov(br)&&br.x<g.y)weight*=1-saturate(br.w);if(cov(body)&&body.x<g.y){weight=0;r.bodyBlocked=1;}r.weight=weight;return r;
}
'''
s=old[:a]+original_sample+curve+old[b:]
a=s.index('void LashCounts583(');b=s.index('bool LashBefore583(',a)
counts='''void LashCounts583(int2 p,int eye,out float4 counts,out float2 curveMean){counts=0;curveMean=0;bool closed=_UseLashRegion583!=0&&_UseClosedLash590!=0;
 for(int k=0;k<16;k++){
  FeatureSample583 baseSample=Sample583(p,eye,k),lash=closed?CurveSample590(p,eye,k):baseSample;
  if(lash.feat==5&&lash.support>=0&&lash.weight>0){counts.x+=lash.weight;float3 d=lash.rest-_Centres348[eye].xyz;curveMean+=lash.weight*float2(dot(d,_AxesX348[eye].xyz)/_AxesX348[eye].w,-dot(d,_AxesY348[eye].xyz)/_AxesY348[eye].w);}
  if(baseSample.support<0||baseSample.weight<=0)continue;
  if(baseSample.feat>=2&&baseSample.feat<=4)counts.y+=baseSample.weight;else if(baseSample.feat==1)counts.z+=baseSample.weight;else if(baseSample.feat==6)counts.w+=baseSample.weight;
 }if(counts.x>0)curveMean/=counts.x;
}
'''
s=s[:a]+counts+s[b:]
s=s.replace('int ChooseRegion583(float c[8],int2 p,int eye){\n if(c[5]>0&&LashAllocated583(p,eye))return c[5]>=5?5:7;', 'int ChooseRegion583(float c[8],int2 p,int eye,float curveCount){\n float lashCount=_UseClosedLash590!=0?curveCount:c[5];if(lashCount>0&&LashAllocated583(p,eye))return lashCount>=5?5:7;')
a=s.index(' for(int eye=0;eye<2;eye++){for(int z=0;z<8;z++)');b=s.index('\n bool domain=',a)
evaluation=''' for(int eye=0;eye<2;eye++){
  for(int z=0;z<8;z++){visibleHist[z]=0;intrinsicHist[z]=0;}int owner=(int)round(_Centres348[eye].w);bool closed590=_UseLashRegion583!=0&&_UseClosedLash590!=0;float curveVisible590=0,curveIntrinsic590=0;
  for(int k=0;k<16;k++){
   labels[k]=0;supports[k]=-1;depths[k]=0;weights[k]=0;if(!inROI)continue;
   if(closed590){FeatureSample583 curve=CurveSample590(p,eye,k);curveIntrinsic590+=LashGeometry590(p,eye,k).x;curveVisible590+=curve.weight;hairBlocked+=curve.hairBlocked;bodyBlocked+=curve.bodyBlocked;}
   FeatureSample583 smp=Sample583(p,eye,k);int feat=smp.feat;if(feat==0)continue;intrinsicHist[feat]++;labels[k]=feat;supports[k]=smp.support;
   if(smp.support<0){if(!closed590||feat!=5)noSupport++;continue;}depths[k]=smp.depth;weights[k]=smp.weight;if(!closed590||feat!=5){hairBlocked+=smp.hairBlocked;bodyBlocked+=smp.bodyBlocked;}visibleHist[feat]+=smp.weight;
  }
  if(closed590)intrinsicHist[5]=curveIntrinsic590;
  int iw=Choose(intrinsicHist);float ic=0;for(int k=1;k<8;k++)ic+=intrinsicHist[k];if(ic>bestIntrinsicCount){bestIntrinsicCount=ic;intrinsicWin=iw;intrinsicEye=eye;histIntrinsic=float4(intrinsicHist[5],intrinsicHist[2]+intrinsicHist[3]+intrinsicHist[4],intrinsicHist[1],intrinsicHist[6]);}
  int w=_UseLashRegion583!=0?ChooseRegion583(visibleHist,p,eye,curveVisible590):Choose(visibleHist);bool curveWinner590=closed590&&(w==5||w==7);float count=curveWinner590?curveVisible590:w>=2&&w<=4?visibleHist[2]+visibleHist[3]+visibleHist[4]:w==7?visibleHist[5]:visibleHist[w];
  if(w>0&&count>winCount){float nearest=1e20;int idx=-1;for(int k=0;k<16;k++){
   if(curveWinner590){FeatureSample583 rep=CurveSample590(p,eye,k);if(rep.support<0||rep.weight<=0)continue;}else if(!sameFeature(labels[k],w)||supports[k]<0||weights[k]<=0)continue;
   float2 d=(float2(k%4,k/4)+.5)/4-.5;float dd=dot(d,d);if(dd<nearest){nearest=dd;idx=k;}}
   if(idx>=0){win=w;eyeWin=eye;winCount=count;repIndex=idx;supportWin=curveWinner590?4:supports[idx];depthWin=curveWinner590?LashGeometry590(p,eye,idx).y:depths[idx];int2 q=lc*4+int2(idx%4,idx/4);
    if(supportWin==4){float4 g=LashGeometry590(p,eye,idx);uvWin=float4(g.zw,0,0);restWin=float4(_Centres348[eye].xyz+_AxesX348[eye].xyz*(g.z*_AxesX348[eye].w)-_AxesY348[eye].xyz*(g.w*_AxesY348[eye].w),1);}else{uvWin=U(supportWin,q);restWin=P(supportWin,q);}
    histVisible=float4(closed590?curveVisible590:visibleHist[5],visibleHist[2]+visibleHist[3]+visibleHist[4],visibleHist[1],visibleHist[6]);}
  }
 }'''
s=s[:a]+evaluation+s[b:]
assert s.count('ChooseRegion583(visibleHist,p,eye,curveVisible590)')==1
assert s[s.index('FeatureSample583 Sample583('):s.index('// Independent geometric overlay.')].strip()==original_sample.strip()
diff=list(difflib.unified_diff(old.splitlines(True),s.splitlines(True),n=2));patch='*** Begin Patch\n*** Update File: '+str(path).replace('\\','/')+'\n'
for line in diff[2:]:patch+='@@\n' if line.startswith('@@') else line
patch+='*** End Patch\n';(R/'SELECTOR_FIX592.patch').write_text(patch,encoding='utf-8');result=subprocess.run([r'C:\Users\15352\AppData\Local\OpenAI\Codex\bin\2993767bd1dfb009\codex.exe','--codex-run-as-apply-patch',patch],capture_output=True);assert result.returncode==0,result.stdout+result.stderr
(R/'SELECTOR_FIX592.json').write_text(json.dumps({'before':hashlib.sha256(old.encode()).hexdigest(),'after':hashlib.sha256(s.encode()).hexdigest(),'baseSampleRestoredVerbatim':True,'fix':'Keep geometric lash overlay independent from original iris/sclera classification; only select the overlay when allocated.'},indent=2)+'\n',encoding='utf-8');print('Shader selector isolation applied; original Sample583 restored verbatim; R2 source retained.')
