from pathlib import Path
import struct,json,csv
import numpy as np
R=Path(__file__).resolve().parent;root=R/'Runtime590/R3/Frozen4'
results=[]
def covered(m):return m[0]>0 and m[1]>.5 and m[3]>1e-6
for f in range(3):
 p=root/f'{f:03}_ON';raw=Path(str(p)+'_LASH_GEOMETRY590.bin').read_bytes();w,h,x,y,eyes=struct.unpack_from('<5i',raw)
 g=np.frombuffer(raw,'<f4',offset=20).reshape(eyes,h*4,w*4,4)
 cells={}
 with Path(str(p)+'_CELLS582.tsv').open() as stream:
  for z in csv.DictReader(stream,delimiter='\t'):
   if z['buffer']=='HairMETA':cells[int(z['cellX']),int(z['cellY'])]=[float(z[c]) for c in ['r','g','b','a']]
 sources={}
 with Path(str(p)+'_SUBPIXELS582.tsv').open() as stream:
  for z in csv.DictReader(stream,delimiter='\t'):
   if int(z['support']) in [5,6]:sources[int(z['cellX']),int(z['cellY']),int(z['k']),int(z['support'])]=[float(z[c]) for c in ['depth','role','eye','alpha']]
 per=[]
 for eye in range(eyes):
  totals=np.zeros(4);visible_cells={}
  for iy,ix in np.argwhere(g[eye,:,:,0]>0):
   a,depth,u,v=g[eye,iy,ix];pt=(x+int(ix)//4,y+int(iy)//4);k=(3-int(iy)%4)*4+int(ix)%4
   hair=cells[pt];br=sources[pt+(k,5)];body=sources[pt+(k,6)];vals=[float(a)]
   if covered(hair) and hair[0]<depth:a*=1-min(1,max(0,hair[3]))
   vals.append(float(a))
   if covered(br) and br[0]<depth:a*=1-min(1,max(0,br[3]))
   vals.append(float(a))
   if covered(body) and body[0]<depth:a=0
   vals.append(float(a));totals+=vals;visible_cells[pt]=visible_cells.get(pt,0)+float(a)/16
  per.append({'modelEyeIndex':eye,'stableEyeId':[2,1][eye],'intrinsicArea':totals[0]/16,'afterHair':totals[1]/16,'afterBrow':totals[2]/16,'afterBody':totals[3]/16,'roundedBudget':int(np.floor(totals[3]/16+.5)),'candidateCells':sum(v>0 for v in visible_cells.values())})
 results.append({'frame':f,'eyes':per})
print(json.dumps(results,indent=2))
(R/'GEOMETRY_TRACE592.json').write_text(json.dumps(results,indent=2)+'\n')
