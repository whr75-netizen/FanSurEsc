from pathlib import Path
import json,hashlib,struct,csv,re
import numpy as np
R=Path(__file__).resolve().parent;P=Path(r'C:\Users\15352\Documents\work\Fantasy Survival Escape Game');A=json.loads((R/'ACTUAL_VALIDATION_R4.json').read_text());runs=A['runs'];pairs=[p for x in runs for p in x['pairs']]
cost={}
for side in ['False','True']:
 z=[c['renderCallMilliseconds'] for c in A['costs'] if c['side']==side];warm=[c['renderCallMilliseconds'] for c in A['costs'] if c['side']==side and c['frame']>0];cost[side]={'allSamples':len(z),'allMedianMs':float(np.median(z)),'allP95Ms':float(np.percentile(z,95)),'excludingFirstOfEachPlanSamples':len(warm),'excludingFirstMedianMs':float(np.median(warm)),'excludingFirstP95Ms':float(np.percentile(warm,95))}
prep=list(csv.DictReader((R/'Runtime590/R4/Turn20/PREPARE_COST592.tsv').open(),delimiter='\t'))
pc={}
for side in ['False','True']:
 v=[float(c['prepareMs']) for c in prep if c['candidate']==side];pc[side]={'samples':len(v),'medianMs':float(np.median(v)),'p95Ms':float(np.percentile(v,95))}
audit=[]
for run in runs:
 for pair in run['pairs']:
  frame=pair['frame'];root=R/'Runtime590/R4'/run['run'];p=root/f'{frame:03}_ON';cells={}
  cellPath=Path(str(p)+('_CELLS581.tsv' if run['run']=='Turn20' else '_CELLS582.tsv'))
  with cellPath.open() as stream:
   for z in csv.DictReader(stream,delimiter='\t'):cells.setdefault((int(z['cellX']),int(z['cellY'])),{})[z['buffer']]=[float(z[c]) for c in ['r','g','b','a']]
  lashes=[(xy,z) for xy,z in cells.items() if int(z['EyeVisible'][0]) in [5,7]]
  failures=[xy for xy,z in cells.items() if z['EyeAudit'][0]==2]
  assert not failures,(run['run'],frame,failures)
  raw=Path(str(p)+'_LASH_GEOMETRY590.bin').read_bytes();w,h,x,y,eyes=struct.unpack_from('<5i',raw);geom=np.frombuffer(raw,'<f4',offset=20).reshape(eyes,h*4,w*4,4);areas=geom[:,:,:,0].sum(axis=(1,2),dtype=np.float64)/16
  audit.append({'run':run['run'],'frame':frame,'fullRoiAudit':run['run']!='Turn20','auditedCells':len(cells),'visibleLashAuditedCells':len(lashes),'geometrySentinelLashCells':sum(z['EyeSurface'][3]==5 for _,z in lashes),'colourFailureCells':len(failures),'geometryBufferBytes':int(geom.nbytes),'intrinsicAreaByModelEyeIndex':areas.tolist()})
log=(R/'unity-validation592-R4.log').read_text('utf-8',errors='replace');errors=re.findall(r'^.*(?:error CS\d+|Shader error|Shader compiler error|Compilation failed|Scripts have compiler errors).*$' ,log,re.M)
assert not errors,errors
controls=json.loads((R/'Runtime590/R4/Turn20/ALLOCATION_CONTROL592.json').read_text())
report={'status':'IMPLEMENTED_AND_RUNTIME_VALIDATED_WITH_REMAINING_TEMPORAL_FAILURE','project':str(P),'editor':r'C:\Users\15352\Documents\work\6000.5.9f1\Editor\Unity.exe','unityVersion':'6000.5.9f1 (b57deb96f08d)','graphics':'D3D11 / AMD Radeon RX 9070 XT','runRoot':str(R/'Runtime590/R4'),'pairs':len(pairs),'pngFrames':len(list((R/'Runtime590/R4').rglob('*.png'))),'compileAndShaderErrors':errors,'preexistingConsoleIssue':'UVCS NotConfiguredClientException / client.conf absent retained in baseline-errors.log; other new error/exception would fail Driver590.','sameFrameCameraTimeAndEyeInputVerifiedPairs':len(pairs),'outsideEyeChangedRGBPixels':sum(p['outsideEyeChangedRGBPixels'] for p in pairs),'savedROISilhouetteChanges':sum(p['savedROISilhouetteChanges'] for p in pairs),'irisToOtherThanLashCells':sum(p['irisToOtherThanLashCells'] for p in pairs),'scleraToOtherThanLashCells':sum(p['scleraToOtherThanLashCells'] for p in pairs),'sourceColourAudit':audit,'remainingReversals':[v for x in runs for v in x['presenceReversals'] if v['side']=='ON'],'fullOcclusionPlans':[x['run'] for x in runs if x['run'] in ['Reg80','Reg260']],'cost':{'wholeRenderCall':cost,'warmEyePrepare':pc,'allocationPositiveControl':controls,'managedAllocation':'UNMEASURED: byte counter remained zero for new 1MiB and 2MiB arrays; render/prepare zero deltas are invalid as allocation evidence.','gpu':'UNMEASURED; no new GPU timing claim. Previous587 raw profiler/GPU attempts were failures; not repeated.','geometryBufferByteRange':[min(x['geometryBufferBytes'] for x in audit),max(x['geometryBufferBytes'] for x in audit)],'scope':'Whole RenderFrame stopwatch includes existing render pipeline CPU work/waits; excludes diagnostic exports/readbacks/file IO. Sequential OFF then ON has order/cold-start bias, no speedup claim. Warm Prepare 5 OFF/5 ON alternates order at fixed last pose; no GPU-only/full Player FPS claim. Retained buffer may stay allocated after OFF; initially dummy16B.'},'limits':['20-frame excerpt only; no full walk loop or repetition seam validation','Remaining eyeID2 lash presence reversal frame4 (1,0,1) follows existing sampled hair depth mask; not resolved by new geometry.','Default UseLashRegion583 remains false. No art adoption.','Only current avatar and prescribed poses/platform exercised; model-generic algorithm is not a claim all models were rendered.','No Player build or real input hardware test in this run.','Full colour audit15 poses; Turn20 has inherited sparse4-cell source audit plus full RGB/visible/intrinsic captures.']}
(R/'VALIDATION592.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k in ['pairs','pngFrames','compileAndShaderErrors','outsideEyeChangedRGBPixels','savedROISilhouetteChanges','irisToOtherThanLashCells','scleraToOtherThanLashCells','remainingReversals','cost']},indent=2))
