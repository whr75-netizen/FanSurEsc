using System;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
[InitializeOnLoad]public static class Driver590
{
 static string Argument(string key){var args=Environment.GetCommandLineArgs();int at=Array.IndexOf(args,key);return at>=0&&at+1<args.Length?args[at+1]:null;}
 public static readonly string Root=(Argument("-validation590-root")??"C:/Users/15352/Documents/Codex/2026-10-26/task/Runtime590/R2/").TrimEnd('/','\\')+"/";
 const string Key="ClosedLash590.";
 [Serializable]public class Pose{public float yaw,phase;}
 [Serializable]public class PoseRun{public int number;public Pose[]poses;}
 [Serializable]public class Fixture{public PoseRun[]cases;}
 static readonly string[] Names=(Argument("-validation590-plans")??"Frozen2,Frozen5,Frozen16,Reg80,Reg170,Reg260,Turn20").Split(',');
 static Driver590(){EditorApplication.update+=Tick;Application.logMessageReceived+=Log;}
 static void Log(string condition,string stack,LogType type)
 {
  if(!SessionState.GetBool(Key+"active",false)||(type!=LogType.Error&&type!=LogType.Exception&&type!=LogType.Assert))return;
  bool baseline=condition.Contains("NotConfiguredClientException")&&condition.Contains("Unity VCS client is not correctly configured for the current user")&&condition.Contains("client.conf not found.");
  File.AppendAllText(Root+(baseline?"baseline-errors.log":"errors.log"),condition+"\n"+stack+"\n");
 }
 public static void Run()
 {
  if(EditorApplication.isPlaying||EditorApplication.isCompiling||Directory.Exists(Root))throw new Exception("590 needs unique output and idle dedicated Editor");
  Directory.CreateDirectory(Root);File.WriteAllText(Root+"status.json","{\"status\":\"STARTED\"}");
  SessionState.SetBool(Key+"active",true);SessionState.SetInt(Key+"index",0);BeginPlay();
 }
 static void BeginPlay(){SessionState.SetString(Key+"stage","warm");SessionState.SetFloat(Key+"deadline",(float)EditorApplication.timeSinceStartup+180);EditorSceneManager.OpenScene("Assets/Scenes/GameMap1.unity");EditorApplication.isPlaying=true;}
 static void Stop(bool passed,string error="")
 {
  SessionState.SetBool(Key+"active",false);EyeFeature348.UseLashRegion583=false;EyeFeature348.UseIrisSurface582=false;EyeFeature348.UseClosedLash590=true;
  File.WriteAllText(Root+"status.json","{\"status\":\""+(passed?"CAPTURED_PENDING_REVIEW":"FAILED")+"\",\"error\":\""+error.Replace("\\","/").Replace("\"","'").Replace("\n"," ").Replace("\r"," ")+"\"}");
  if(EditorApplication.isPlaying)EditorApplication.isPlaying=false;
  EditorApplication.delayCall+=()=>EditorApplication.Exit(passed?0:1);
 }
 static void Tick()
 {
  if(!SessionState.GetBool(Key+"active",false))return;
  try
  {
   if(File.Exists(Root+"errors.log")){Stop(false,"Unity Error/Exception; see errors.log");return;}
   if(EditorApplication.timeSinceStartup>SessionState.GetFloat(Key+"deadline",0)){Stop(false,"Stage deadline");return;}
   int index=SessionState.GetInt(Key+"index",0);string name=Names[index],stage=SessionState.GetString(Key+"stage","");
   if(stage=="warm")
   {
    if(!EditorApplication.isPlaying)return;Application.runInBackground=true;
    var g=UnityEngine.Object.FindFirstObjectByType<Gameplay397>();if(!g||!g.connected||g.runInputTest&&!g.testFinished){EditorApplication.QueuePlayerLoopUpdate();return;}
    if(!string.IsNullOrEmpty(g.failure)||!string.IsNullOrEmpty(g.player.failure)){Stop(false,g.failure+g.player.failure);return;}
    bool frozen=name.StartsWith("Frozen");if(frozen){var fixture=JsonUtility.FromJson<Fixture>(File.ReadAllText("C:/Users/15352/Documents/Codex/2026-10-26/task/POSES590.json"));var poses=fixture.cases.First(x=>name=="Frozen"+x.number).poses;Probe590.FrozenPoses590=poses.Select(x=>new[]{x.yaw,x.phase}).ToArray();}
    else Probe590.FrozenPoses590=null;
    float yaw=frozen?Probe590.FrozenPoses590[0][0]:name=="Reg80"?80:name=="Reg170"?170:name=="Reg260"?260:125.500038f;
    SessionState.SetString(Key+"stage","capture");SessionState.SetFloat(Key+"deadline",(float)EditorApplication.timeSinceStartup+900);
    Probe590.Start(yaw,"",name,Enumerable.Range(0,frozen?3:name=="Turn20"?20:2).ToArray(),frozen?Probe590.FrozenPoses590[0][1]:name=="Turn20"?1.6750042f:1.16250336f,name=="Turn20"?170:float.NaN,name=="Turn20"?170:float.NaN,1000);
   }
   else if(stage=="capture")
   {
    string file=Root+name+"/status.json";if(!File.Exists(file))return;string text=File.ReadAllText(file);if(text.Contains("\"FAILED\"")){Stop(false,text);return;}
    if(!text.Contains("\"CAPTURED\"")||EditorApplication.isPlayingOrWillChangePlaymode)return;
    File.AppendAllText(Root+"completed.txt",name+"\n");index++;if(index==Names.Length){Stop(true);return;}SessionState.SetInt(Key+"index",index);BeginPlay();
   }
  }
  catch(Exception error){Stop(false,error.ToString());}
 }
}
